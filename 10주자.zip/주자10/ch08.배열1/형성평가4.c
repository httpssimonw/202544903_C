#include <stdio.h>

int main(void) {
    double arr[6];
    double sum = 0;
    int i;

    for (i = 0; i < 6; i++) {
        scanf("%lf", &arr[i]);
        sum += arr[i];
    }

    printf("%.1f", sum / 6 + 0.00001);

    return 0;
}
