#include <stdio.h>

int main(void) {
    int arr[100];
    int n = 0;
    int x, i, cnt = 0, sum = 0;

    while (n < 100) {
        scanf("%d", &x);
        if (x == 0) break;
        arr[n] = x;
        n++;
    }

    for (i = 0; i < n; i++) {
        if (arr[i] % 5 == 0) {
            cnt++;
            sum += arr[i];
        }
    }

    printf("Multiples of 5 : %d\n", cnt);
    printf("sum : %d\n", sum);
    if (cnt > 0) printf("avg : %.1f", (double)sum / cnt + 0.00001);
    else printf("avg : 0.0");

    return 0;
}
