#include <stdio.h>

int main(void) {
    int score[10];
    int i, even = 0, odd = 0;

    for (i = 0; i < 10; i++) {
        scanf("%d", &score[i]);
    }
    for (i = 0; i < 10; i++) {
        if (i % 2 == 1) even += score[i];
        else odd += score[i];
    }

    printf("sum : %d\n", even);
    printf("avg : %.1f", odd / 5.0 + 0.00001);

    return 0;
}
