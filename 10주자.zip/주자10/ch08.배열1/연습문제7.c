#include <stdio.h>

int main(void) {
    int arr[10];
    int i, sum = 0;

    for (i = 0; i < 10; i++) {
        scanf("%d", &arr[i]);
        sum += arr[i];
    }

    printf("sum = %d\n", sum);
    printf("avg = %.1f", sum / 10.0 + 0.00001);

    return 0;
}
