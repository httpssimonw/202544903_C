#include <stdio.h>

int main(void) {
    int arr[10];
    int i, min = 1001;

    for (i = 0; i < 10; i++) {
        scanf("%d", &arr[i]);
    }
    for (i = 0; i < 10; i++) {
        if (arr[i] < min) min = arr[i];
    }

    printf("%d", min);

    return 0;
}
