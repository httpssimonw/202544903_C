#include <stdio.h>

int main(void) {
    int arr[100];
    int n = 0;
    int x, i;

    while (n < 100) {
        scanf("%d", &x);
        if (x == 0) break;
        arr[n] = x;
        n++;
    }

    for (i = n - 1; i >= 0; i--) {
        printf("%d ", arr[i]);
    }

    return 0;
}
