#include <stdio.h>

int main(void) {
    int arr[100];
    int n = 0;
    int x, i, max, min;

    while (n < 100) {
        scanf("%d", &x);
        if (x == 0) break;
        arr[n] = x;
        n++;
    }

    max = arr[0];
    min = arr[0];
    for (i = 1; i < n; i++) {
        if (arr[i] > max) max = arr[i];
        if (arr[i] < min) min = arr[i];
    }

    printf("%d", max + min);

    return 0;
}
