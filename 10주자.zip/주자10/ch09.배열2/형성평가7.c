#include <stdio.h>

int main(void) {
    int arr[4][2];
    int i, j, sum, total = 0;

    for (i = 0; i < 4; i++) {
        for (j = 0; j < 2; j++) {
            scanf("%d", &arr[i][j]);
            total += arr[i][j];
        }
    }

    for (i = 0; i < 4; i++) {
        sum = 0;
        for (j = 0; j < 2; j++) {
            sum += arr[i][j];
        }
        printf("%d ", sum / 2);
    }
    printf("\n");

    for (j = 0; j < 2; j++) {
        sum = 0;
        for (i = 0; i < 4; i++) {
            sum += arr[i][j];
        }
        printf("%d ", sum / 4);
    }
    printf("\n");

    printf("%d", total / 8);

    return 0;
}
