#include <stdio.h>

int main(void) {
    int arr[6][6] = {0};
    int i, j;

    arr[0][1] = 1;
    for (i = 1; i <= 5; i++) {
        for (j = 1; j <= 5; j++) {
            arr[i][j] = arr[i - 1][j] + arr[i][j - 1];
        }
    }

    for (i = 1; i <= 5; i++) {
        for (j = 1; j <= 5; j++) {
            printf("%d ", arr[i][j]);
        }
        printf("\n");
    }

    return 0;
}
