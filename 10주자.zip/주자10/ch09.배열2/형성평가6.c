#include <stdio.h>

int main(void) {
    int arr[5][7] = {0};
    int i, j;

    arr[0][1] = 1;
    arr[0][3] = 1;
    arr[0][5] = 1;
    for (i = 1; i < 5; i++) {
        for (j = 1; j <= 5; j++) {
            arr[i][j] = arr[i - 1][j - 1] + arr[i - 1][j + 1];
        }
    }

    for (i = 0; i < 5; i++) {
        for (j = 1; j <= 5; j++) {
            printf("%d ", arr[i][j]);
        }
        printf("\n");
    }

    return 0;
}
