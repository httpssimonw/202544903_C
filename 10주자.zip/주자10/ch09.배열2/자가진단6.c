#include <stdio.h>

int main(void) {
    int arr[5][4];
    int i, j, sum;

    for (i = 0; i < 5; i++) {
        sum = 0;
        for (j = 0; j < 4; j++) {
            scanf("%d", &arr[i][j]);
            sum += arr[i][j];
        }
        printf("%d %.1f\n", sum, sum / 4.0 + 0.00001);
    }

    return 0;
}
