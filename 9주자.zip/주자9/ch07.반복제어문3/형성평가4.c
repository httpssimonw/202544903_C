#include <stdio.h>

int main(void) {
    int n, i, j;

    scanf("%d", &n);

    for (i = 1; i <= n; i++) {
        for (j = 1; j <= n - i; j++) {
            printf("  ");
        }

        for (j = 1; j <= i; j++) {
            if (j > 1) printf(" ");
            printf("%d", j);
        }

        printf("\n");
    }

    return 0;
}
