#include <stdio.h>

int main(void){
    int a;

    for(a=10;a<=20;a++){
        printf("%d",a);
    }
    return 0;
}
