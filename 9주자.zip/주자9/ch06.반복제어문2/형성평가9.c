#include <stdio.h>

int main(void) {
    int n, i, j;

    scanf("%d", &n);

    for (i = 1; i <= n; i++) {
        for (j = 1; j <= n; j++) {
            printf("(%d, %d)", i, j);
            if (j < n) printf(" ");
        }
        printf("\n");
    }

    return 0;
}
