#include <stdio.h>

struct point {
    double x;
    double y;
};

int main(void) {
    struct point p1, p2, c;

    scanf("%lf %lf", &p1.x, &p1.y);
    scanf("%lf %lf", &p2.x, &p2.y);

    c.x = (p1.x + p2.x) / 2;
    c.y = (p1.y + p2.y) / 2;

    printf("Center point = (%.1f, %.1f)", c.x, c.y);

    return 0;
}
