#include <stdio.h>

struct school {
    char name[50];
    int grade;
};

int main(void) {
    struct school a = {"Jejuelementary", 6};
    struct school b;

    scanf("%s %d", b.name, &b.grade);

    printf("%d grade in %s School\n", a.grade, a.name);
    printf("%d grade in %s School", b.grade, b.name);

    return 0;
}
