#include <stdio.h>

int main(void) {
    char myName[20] = "Yejun";
    int myAge = 12;
    char name[20];
    int age;

    scanf("%s %d", name, &age);

    printf("Your name: %s, age: %d\n", myName, myAge);
    printf("Friend's name: %s, age: %d", name, age);

    return 0;
}
