#include <stdio.h>

struct Student {
    char name[21];
    int score[3];
    int total;
};

void input(struct Student arr[], int n) {
    int i, j;

    for (i = 0; i < n; i++) {
        scanf("%s", arr[i].name);
        arr[i].total = 0;
        for (j = 0; j < 3; j++) {
            scanf("%d", &arr[i].score[j]);
            arr[i].total += arr[i].score[j];
        }
    }
}

void sort(struct Student arr[], int n) {
    struct Student temp;
    int i, j;

    for (i = 0; i < n - 1; i++) {
        for (j = 0; j < n - 1 - i; j++) {
            if (arr[j].total < arr[j + 1].total) {
                temp = arr[j];
                arr[j] = arr[j + 1];
                arr[j + 1] = temp;
            }
        }
    }
}

void output(struct Student arr[], int n) {
    int i, j;

    for (i = 0; i < n; i++) {
        printf("%s", arr[i].name);
        for (j = 0; j < 3; j++) {
            printf(" %d", arr[i].score[j]);
        }
        printf(" %d\n", arr[i].total);
    }
}

int main(void) {
    struct Student arr[10];
    int n;

    scanf("%d", &n);

    input(arr, n);
    sort(arr, n);
    output(arr, n);

    return 0;
}
