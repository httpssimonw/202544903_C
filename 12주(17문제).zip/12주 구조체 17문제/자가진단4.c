#include <stdio.h>

struct person {
    char name[21];
    int height;
};

int main(void) {
    struct person p[5];
    int i, minIdx = 0;

    for (i = 0; i < 5; i++) {
        scanf("%s %d", p[i].name, &p[i].height);
    }

    for (i = 1; i < 5; i++) {
        if (p[i].height < p[minIdx].height) {
            minIdx = i;
        }
    }

    printf("%s %d", p[minIdx].name, p[minIdx].height);

    return 0;
}
