#include <stdio.h>

struct rect {
    int x1, y1, x2, y2;
};

int main(void) {
    struct rect a, b, c;

    scanf("%d %d %d %d", &a.x1, &a.y1, &a.x2, &a.y2);
    scanf("%d %d %d %d", &b.x1, &b.y1, &b.x2, &b.y2);

    c.x1 = (a.x1 < b.x1) ? a.x1 : b.x1;
    c.y1 = (a.y1 < b.y1) ? a.y1 : b.y1;
    c.x2 = (a.x2 > b.x2) ? a.x2 : b.x2;
    c.y2 = (a.y2 > b.y2) ? a.y2 : b.y2;

    printf("%d %d %d %d", c.x1, c.y1, c.x2, c.y2);

    return 0;
}
