#include <stdio.h>

struct Body {
    int height;
    double weight;
};

struct Body makeStudent(struct Body f, struct Body m) {
    struct Body s;
    s.height = (f.height + m.height) / 2 + 5;
    s.weight = (f.weight + m.weight) / 2 - 4.5 + 0.00001;
    return s;
}

int main(void) {
    struct Body father, mother, student;

    scanf("%d %lf", &father.height, &father.weight);
    scanf("%d %lf", &mother.height, &mother.weight);

    student = makeStudent(father, mother);

    printf("height : %dcm\n", student.height);
    printf("weight : %.1fkg", student.weight);

    return 0;
}
