#include <stdio.h>

struct Score {
    char name[21];
    int kor;
    int eng;
};

struct Score plus_(struct Score a, struct Score b) {
    struct Score r = {"Total", 0, 0};
    r.kor = a.kor + b.kor;
    r.eng = a.eng + b.eng;
    return r;
}

int main(void) {
    struct Score a, b, result;

    scanf("%s %d %d", a.name, &a.kor, &a.eng);
    scanf("%s %d %d", b.name, &b.kor, &b.eng);

    result = plus_(a, b);

    printf("%s %d %d\n", a.name, a.kor, a.eng);
    printf("%s %d %d\n", b.name, b.kor, b.eng);
    printf("%s %d %d\n", result.name, result.kor, result.eng);

    return 0;
}
