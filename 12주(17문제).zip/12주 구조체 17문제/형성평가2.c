#include <stdio.h>

struct info {
    char name[101];
    char tel[101];
    char addr[101];
};

int compare(char a[], char b[]) {
    int i = 0;

    while (a[i] != '\0' && a[i] == b[i]) {
        i++;
    }
    return a[i] - b[i];
}

int main(void) {
    struct info p[3];
    int i, minIdx = 0;

    for (i = 0; i < 3; i++) {
        scanf("%s %s %s", p[i].name, p[i].tel, p[i].addr);
    }

    for (i = 1; i < 3; i++) {
        if (compare(p[i].name, p[minIdx].name) < 0) {
            minIdx = i;
        }
    }

    printf("name : %s\n", p[minIdx].name);
    printf("tel : %s\n", p[minIdx].tel);
    printf("addr : %s", p[minIdx].addr);

    return 0;
}
