#include <stdio.h>

struct student {
    char name[21];
    int score;
};

int main(void) {
    struct student s[5];
    int i, maxIdx = 0;

    for (i = 0; i < 5; i++) {
        scanf("%s %d", s[i].name, &s[i].score);
    }

    for (i = 1; i < 5; i++) {
        if (s[i].score > s[maxIdx].score) {
            maxIdx = i;
        }
    }

    printf("%s %d", s[maxIdx].name, s[maxIdx].score);

    return 0;
}
