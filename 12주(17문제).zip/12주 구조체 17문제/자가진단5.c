#include <stdio.h>

struct person {
    char name[21];
    int height;
    double weight;
};

int compare(char a[], char b[]) {
    int i = 0;

    while (a[i] != '\0' && a[i] == b[i]) {
        i++;
    }
    return a[i] - b[i];
}

int main(void) {
    struct person p[5], temp;
    int i, j;

    for (i = 0; i < 5; i++) {
        scanf("%s %d %lf", p[i].name, &p[i].height, &p[i].weight);
    }

    for (i = 0; i < 4; i++) {
        for (j = 0; j < 4 - i; j++) {
            if (compare(p[j].name, p[j + 1].name) > 0) {
                temp = p[j];
                p[j] = p[j + 1];
                p[j + 1] = temp;
            }
        }
    }

    for (i = 0; i < 5; i++) {
        printf("%s %d %.1f\n", p[i].name, p[i].height, p[i].weight);
    }

    return 0;
}
