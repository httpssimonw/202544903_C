#include <stdio.h>

int main(void) {
    char name[21], school[21];
    int grade;

    scanf("%s %s %d", name, school, &grade);

    printf("Name : %s\n", name);
    printf("School : %s\n", school);
    printf("Grade : %d", grade);

    return 0;
}
