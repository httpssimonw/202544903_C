#include <stdio.h>

struct person {
    char name[21];
    int age;
};

int main(void) {
    struct person p[3];
    int i;

    for (i = 0; i < 3; i++) {
        scanf("%s %d", p[i].name, &p[i].age);
    }

    for (i = 0; i < 3; i++) {
        printf("Name : %s\n", p[i].name);
        printf("Age : %d\n", p[i].age);
    }

    return 0;
}
