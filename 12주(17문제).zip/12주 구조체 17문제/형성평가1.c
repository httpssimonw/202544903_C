#include <stdio.h>

struct info {
    char name[101];
    char tel[101];
    char addr[101];
};

int main(void) {
    struct info a;

    scanf("%s %s %s", a.name, a.tel, a.addr);

    printf("name : %s\n", a.name);
    printf("tel : %s\n", a.tel);
    printf("addr : %s", a.addr);

    return 0;
}
